
export type Rewatchability = 'Low' | 'Medium' | 'High' | 'Instant Classic';

export interface ShowMetadata {
  id: string;
  tmdbId: number;
  title: string;
  seasonNumber: number;
  posterUrl: string;
  network: string;
  genres: string[];
  airDateStart: string;
  episodeCount: number;
}

export interface RankingEntry {
  id: string;
  userId: string;
  show: ShowMetadata;
  rankPosition: number;
  rewatchability?: Rewatchability;
  score?: number;
  review?: string;
  lastRevised: string;
}

export interface User {
  id: string;
  displayName: string;
  avatarUrl: string;
  role: 'admin' | 'contributor';
}

export interface AwardCategory {
  id: string;
  name: string;
  year: number;
  isPreset: boolean;
  unanimous?: boolean;
}

export interface AwardPick {
  id: string;
  categoryId: string;
  userId: string;
  showId: string;
  blurb?: string;
}

export interface ActivityEvent {
  id: string;
  userId: string;
  type: 'add' | 'move' | 'remove' | 'finalize' | 'award_pick' | 'blog_post';
  timestamp: string;
  metadata: {
    showName?: string;
    oldRank?: number;
    newRank?: number;
    awardName?: string;
    postTitle?: string;
  };
}
