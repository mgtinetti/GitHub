
import React from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import HomePage from './pages/HomePage';
import RankingsPage from './pages/RankingsPage';
import AwardsPage from './pages/AwardsPage';
import { ACCENT_COLOR } from './constants';

const Navbar: React.FC = () => {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 glass border-b border-white/5 px-4 md:px-8 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className={`w-8 h-8 rounded-lg bg-${ACCENT_COLOR} flex items-center justify-center font-bold text-black shadow-lg shadow-${ACCENT_COLOR}/20 group-hover:scale-110 transition-transform`}>
            R
          </div>
          <span className="font-bold text-xl tracking-tight hidden sm:inline">RTVG RANKINGS</span>
        </Link>
        
        <div className="flex items-center gap-4 md:gap-8">
          <div className="flex items-center gap-4 md:gap-6 text-sm font-medium">
            <Link to="/2025" className={`${isActive('/2025') ? `text-${ACCENT_COLOR}` : 'text-gray-400 hover:text-white'} transition-colors`}>2025</Link>
            <Link to="/awards" className={`${isActive('/awards') ? `text-${ACCENT_COLOR}` : 'text-gray-400 hover:text-white'} transition-colors`}>Awards</Link>
            <Link to="/lists" className="text-gray-400 hover:text-white transition-colors">Lists</Link>
            <Link to="/blog" className="text-gray-400 hover:text-white transition-colors">Blog</Link>
          </div>
          
          <button className="hidden md:block bg-white/5 hover:bg-white/10 px-4 py-1.5 rounded-full text-xs font-semibold border border-white/10 transition-colors">
            SIGN IN
          </button>
        </div>
      </div>
    </nav>
  );
};

const App: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen text-gray-200">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/:year" element={<RankingsPage />} />
          <Route path="/awards" element={<AwardsPage />} />
        </Routes>
      </main>
      <footer className="py-12 px-8 border-t border-white/5 text-center text-gray-500 text-sm">
        <p>© 2026 RTVG Rankings. Built for Matt, Mike & Jake.</p>
      </footer>
    </div>
  );
};

export default App;
