
import React, { useState } from 'react';
import { MOCK_RANKINGS, MOCK_USERS } from '../mockData';
import RankingCard from './RankingCard';
import { ACCENT_COLOR } from '../constants';

const SideBySideView: React.FC = () => {
  const [activeTab, setActiveTab] = useState(MOCK_USERS[0].id);
  const [hoveredShow, setHoveredShow] = useState<string | null>(null);

  return (
    <div className="w-full">
      {/* Mobile Tabs */}
      <div className="flex md:hidden mb-6 bg-white/5 p-1 rounded-xl glass">
        {MOCK_USERS.map((user) => (
          <button
            key={user.id}
            onClick={() => setActiveTab(user.id)}
            className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${
              activeTab === user.id ? `bg-${ACCENT_COLOR} text-black shadow-lg` : 'text-gray-400'
            }`}
          >
            {user.displayName}
          </button>
        ))}
      </div>

      {/* Desktop Columns / Mobile Single Col */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {MOCK_USERS.map((user) => (
          <div 
            key={user.id} 
            className={`flex flex-col gap-4 ${activeTab === user.id ? 'block' : 'hidden md:flex'}`}
          >
            <div className="flex items-center gap-3 mb-2 px-2">
              <img src={user.avatarUrl} alt={user.displayName} className={`w-10 h-10 rounded-full border-2 border-${ACCENT_COLOR}`} />
              <h2 className="text-xl font-bold">{user.displayName}</h2>
              <div className="flex-grow h-px bg-white/10"></div>
              <span className="text-xs font-mono text-gray-500 uppercase">Top 10</span>
            </div>
            
            <div className="space-y-4">
              {MOCK_RANKINGS[user.id].slice(0, 10).map((entry) => (
                <div 
                  key={entry.id}
                  onMouseEnter={() => setHoveredShow(entry.show.title)}
                  onMouseLeave={() => setHoveredShow(null)}
                >
                  <RankingCard 
                    entry={entry} 
                    compact 
                    highlighted={hoveredShow === entry.show.title}
                  />
                </div>
              ))}
            </div>
            
            <button className="mt-4 py-3 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-400 uppercase tracking-widest transition-colors">
              View Full List →
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SideBySideView;
