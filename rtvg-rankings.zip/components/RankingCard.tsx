
import React from 'react';
import { RankingEntry } from '../types';
import { ACCENT_COLOR, REWATCH_ICONS } from '../constants';

interface RankingCardProps {
  entry: RankingEntry;
  compact?: boolean;
  highlighted?: boolean;
}

const RankingCard: React.FC<RankingCardProps> = ({ entry, compact = false, highlighted = false }) => {
  const { show, rankPosition, score, rewatchability } = entry;

  if (compact) {
    return (
      <div className={`flex items-center gap-3 p-2 rounded-xl glass hover:bg-white/10 transition-all cursor-pointer group ${highlighted ? `ring-2 ring-${ACCENT_COLOR} bg-${ACCENT_COLOR}/5` : ''}`}>
        <div className={`w-8 h-8 flex items-center justify-center font-bold text-lg ${rankPosition <= 3 ? `text-${ACCENT_COLOR}` : 'text-gray-500'}`}>
          {rankPosition}
        </div>
        <img src={show.posterUrl} alt={show.title} className="w-10 h-14 object-cover rounded-md shadow-lg" />
        <div className="flex-grow min-w-0">
          <h4 className="font-bold text-sm truncate group-hover:text-white transition-colors">{show.title}</h4>
          <p className="text-xs text-gray-400">S{show.seasonNumber}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden group rounded-2xl glass p-4 hover:shadow-2xl hover:shadow-${ACCENT_COLOR}/10 transition-all border border-white/5 hover:border-${ACCENT_COLOR}/30 ${highlighted ? `ring-1 ring-${ACCENT_COLOR}/50` : ''}`}>
      {/* Rank Badge */}
      <div className={`absolute -top-1 -left-1 w-12 h-12 flex items-center justify-center text-xl font-black bg-${ACCENT_COLOR} text-black rounded-br-2xl shadow-xl z-10`}>
        #{rankPosition}
      </div>

      <div className="flex gap-5">
        <div className="relative shrink-0 w-32 md:w-40 aspect-[2/3] overflow-hidden rounded-xl shadow-2xl">
          <img 
            src={show.posterUrl} 
            alt={show.title} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
             <span className="text-xs font-bold text-white uppercase tracking-widest">{show.network}</span>
          </div>
        </div>

        <div className="flex flex-col justify-between flex-grow py-1">
          <div>
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3 className="text-xl md:text-2xl font-bold leading-tight group-hover:text-white">{show.title}</h3>
              {score && (
                <div className={`px-2 py-1 rounded bg-${ACCENT_COLOR}/10 border border-${ACCENT_COLOR}/20 text-${ACCENT_COLOR} text-xs font-bold whitespace-nowrap`}>
                  ★ {score}/10
                </div>
              )}
            </div>
            <p className="text-sm text-gray-400 mb-3">Season {show.seasonNumber} • {show.network}</p>
            
            <div className="flex flex-wrap gap-2 mb-4">
              {show.genres.map(g => (
                <span key={g} className="px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-[10px] text-gray-400 uppercase tracking-wider">{g}</span>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-gray-400 border-t border-white/5 pt-3">
            <div className="flex items-center gap-1.5">
              <span className="opacity-70">Episodes:</span>
              <span className="font-medium text-gray-200">{show.episodeCount}</span>
            </div>
            {rewatchability && (
              <div className="flex items-center gap-1.5 bg-white/5 px-2 py-1 rounded-lg">
                <span className="text-sm" title={rewatchability}>{REWATCH_ICONS[rewatchability]}</span>
                <span className="font-semibold text-gray-300">{rewatchability}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RankingCard;
