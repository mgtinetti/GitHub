
import React from 'react';
import { MOCK_ACTIVITY, MOCK_USERS } from '../mockData';
import { ACCENT_COLOR } from '../constants';

const ActivityFeed: React.FC = () => {
  const getEventText = (event: any) => {
    const user = MOCK_USERS.find(u => u.id === event.userId);
    const userName = user?.displayName || 'Someone';

    switch (event.type) {
      case 'add':
        return (
          <p>
            <span className="font-bold text-white">{userName}</span> added <span className={`text-${ACCENT_COLOR}`}>{event.metadata.showName}</span> at #{event.metadata.newRank}
          </p>
        );
      case 'move':
        return (
          <p>
            <span className="font-bold text-white">{userName}</span> moved <span className={`text-${ACCENT_COLOR}`}>{event.metadata.showName}</span> from #{event.metadata.oldRank} to #{event.metadata.newRank}
          </p>
        );
      case 'finalize':
        return (
          <p>
            <span className="font-bold text-white">{userName}</span> marked their 2025 rankings as <span className="text-emerald-400">finalized</span>
          </p>
        );
      case 'blog_post':
        return (
          <p>
            <span className="font-bold text-white">{userName}</span> published a new post: <span className="italic">"{event.metadata.postTitle}"</span>
          </p>
        );
      default:
        return null;
    }
  };

  const getTimeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <div className="space-y-4">
      {MOCK_ACTIVITY.map((event) => (
        <div key={event.id} className="flex gap-4 group">
          <div className="flex flex-col items-center">
            <div className={`w-2 h-2 rounded-full bg-${ACCENT_COLOR} ring-4 ring-${ACCENT_COLOR}/10 mb-1 mt-2`}></div>
            <div className="w-px h-full bg-white/10 group-last:hidden"></div>
          </div>
          <div className="pb-6">
            <div className="text-sm text-gray-400 leading-relaxed mb-1">
              {getEventText(event)}
            </div>
            <span className="text-[10px] font-mono uppercase text-gray-600 tracking-tighter">
              {getTimeAgo(event.timestamp)}
            </span>
          </div>
        </div>
      ))}
      <button className="w-full py-3 rounded-xl border border-white/5 text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 hover:text-white hover:bg-white/5 transition-all">
        View All Activity
      </button>
    </div>
  );
};

export default ActivityFeed;
