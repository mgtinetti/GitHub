
export const ACCENT_COLOR = 'amber-500';
export const BG_DARK = '#0a0a0f';
export const SURFACE_DARK = '#1a1a2e';

export const USER_IDS = {
  MATT: 'matt-id',
  MIKE: 'mike-id',
  JAKE: 'jake-id',
};

export const REWATCH_ICONS: Record<string, string> = {
  'Low': '⏹️',
  'Medium': '⏯️',
  'High': '🔄',
  'Instant Classic': '⭐',
};
