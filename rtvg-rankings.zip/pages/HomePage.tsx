
import React from 'react';
import SideBySideView from '../components/SideBySideView';
import ActivityFeed from '../components/ActivityFeed';
import { ACCENT_COLOR } from '../constants';

const HomePage: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-1000">
      {/* Hero Section */}
      <section className="relative h-[40vh] md:h-[50vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/tv-hero/1920/1080" 
            className="w-full h-full object-cover opacity-20 scale-110 blur-sm"
            alt="Hero Background"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f]/80 to-transparent"></div>
        </div>
        
        <div className="relative z-10 text-center px-4">
          <h1 className="text-5xl md:text-8xl font-black tracking-tighter mb-4 italic uppercase">
            REAL TV GUY <span className={`text-${ACCENT_COLOR}`}>RANKINGS</span>
          </h1>
          <p className="max-w-2xl mx-auto text-gray-400 text-lg md:text-xl font-light">
            The definitive record of our television journey
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
          {/* Main Content: Side by Side Rankings */}
          <div className="lg:col-span-3">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-black uppercase tracking-tight">2025 Rankings</h2>
              <div className={`h-1 w-20 bg-${ACCENT_COLOR} rounded-full hidden sm:block`}></div>
            </div>
            <SideBySideView />
          </div>

          {/* Sidebar: Activity Feed */}
          <div className="lg:col-span-1">
            <h2 className="text-xl font-black uppercase tracking-tight mb-8">Activity Feed</h2>
            <ActivityFeed />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
