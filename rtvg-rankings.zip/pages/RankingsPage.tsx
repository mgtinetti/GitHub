
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import RankingCard from '../components/RankingCard';
import { MOCK_RANKINGS, MOCK_USERS } from '../mockData';
import { ACCENT_COLOR } from '../constants';

const RankingsPage: React.FC = () => {
  const { year } = useParams<{ year: string }>();
  const [viewMode, setViewMode] = useState<'individual' | 'side-by-side' | 'consensus'>('side-by-side');
  const [selectedUser, setSelectedUser] = useState(MOCK_USERS[0].id);

  const rankings = MOCK_RANKINGS[selectedUser] || [];

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-12 animate-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
        <div>
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-4 uppercase">{year} <span className={`text-${ACCENT_COLOR}`}>Rankings</span></h1>
          <div className="flex items-center gap-4 text-sm text-gray-500 font-mono uppercase">
            <span>Last Updated: Feb 6, 2026</span>
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-lg shadow-emerald-500/50"></div>
            <span className="text-emerald-400">Finalized</span>
          </div>
        </div>

        <div className="flex gap-2 bg-white/5 p-1 rounded-xl glass shrink-0">
          {(['side-by-side', 'consensus', 'individual'] as const).map(mode => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${
                viewMode === mode ? `bg-${ACCENT_COLOR} text-black` : 'text-gray-400 hover:text-white'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {viewMode === 'individual' ? (
        <div className="space-y-12">
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {MOCK_USERS.map(user => (
              <button
                key={user.id}
                onClick={() => setSelectedUser(user.id)}
                className={`flex items-center gap-3 px-6 py-3 rounded-2xl glass shrink-0 transition-all ${
                  selectedUser === user.id ? `ring-2 ring-${ACCENT_COLOR} bg-${ACCENT_COLOR}/10` : 'opacity-50 hover:opacity-100'
                }`}
              >
                <img src={user.avatarUrl} className="w-8 h-8 rounded-full" alt="" />
                <span className="font-bold">{user.displayName}</span>
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {rankings.map(entry => (
              <RankingCard key={entry.id} entry={entry} />
            ))}
          </div>
        </div>
      ) : viewMode === 'consensus' ? (
        <div className="glass rounded-3xl p-8 md:p-12 text-center">
          <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="text-4xl italic text-gray-700 font-black">?</span>
          </div>
          <h2 className="text-2xl font-bold mb-4">Consensus Logic Loading</h2>
          <p className="text-gray-400 max-w-md mx-auto mb-8">
            The group algorithm is currently crunching the numbers to determine our unified 2025 rankings. Check back soon.
          </p>
          <button 
            onClick={() => setViewMode('side-by-side')}
            className={`bg-${ACCENT_COLOR} text-black font-bold px-8 py-3 rounded-xl hover:scale-105 transition-transform`}
          >
            Go Back to Side-by-Side
          </button>
        </div>
      ) : (
        <div className="bg-white/5 rounded-3xl p-6 glass">
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {MOCK_USERS.map(user => (
                <div key={user.id} className="space-y-4">
                  <div className="text-center mb-6">
                    <img src={user.avatarUrl} className={`w-20 h-20 rounded-full mx-auto mb-3 border-4 border-${ACCENT_COLOR}/30`} alt="" />
                    <h3 className="text-xl font-black uppercase tracking-tight">{user.displayName}</h3>
                  </div>
                  <div className="space-y-3">
                    {MOCK_RANKINGS[user.id].map(entry => (
                      <RankingCard key={entry.id} entry={entry} compact />
                    ))}
                  </div>
                </div>
              ))}
           </div>
        </div>
      )}
    </div>
  );
};

export default RankingsPage;
