
import React from 'react';
import { MOCK_AWARD_CATEGORIES, MOCK_AWARD_PICKS, MOCK_USERS } from '../mockData';
import { ACCENT_COLOR } from '../constants';

const AwardsPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-12 animate-in zoom-in duration-1000">
      <div className="text-center mb-16">
        <span className={`text-${ACCENT_COLOR} font-mono uppercase tracking-[0.5em] text-xs mb-4 block`}>Year End Superlatives</span>
        <h1 className="text-5xl md:text-8xl font-black tracking-tighter mb-4 italic uppercase">2025 <span className={`text-${ACCENT_COLOR}`}>AWARDS</span></h1>
        <p className="text-gray-400 max-w-xl mx-auto">Our personal TV awards ceremony. Votes cast, arguments had, and group winners declared.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {MOCK_AWARD_CATEGORIES.map(category => {
          const picks = MOCK_AWARD_PICKS.filter(p => p.categoryId === category.id);
          const showOfTarget = picks[0]?.showId; // Mocking winner logic
          
          return (
            <div key={category.id} className="relative group rounded-3xl glass p-8 overflow-hidden border border-white/5 hover:border-amber-500/30 transition-all">
              {category.unanimous && (
                <div className="absolute top-4 right-4 bg-amber-500/20 text-amber-500 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest border border-amber-500/30 animate-pulse">
                  Unanimous Pick
                </div>
              )}
              
              <div className="mb-8">
                <span className="text-amber-500 text-3xl mb-4 block">🏆</span>
                <h2 className="text-2xl md:text-3xl font-black uppercase tracking-tight mb-2">{category.name}</h2>
                <div className="h-0.5 w-12 bg-amber-500"></div>
              </div>

              <div className="space-y-6">
                <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                  <span className="text-[10px] font-bold text-gray-500 uppercase block mb-3">Group Winner</span>
                  <div className="flex items-center gap-4">
                    <img src={`https://picsum.photos/seed/${category.name}/150/225`} className="w-16 h-24 object-cover rounded-lg shadow-xl" alt="" />
                    <div>
                      <h4 className="text-xl font-bold text-white">Severance</h4>
                      <p className="text-xs text-amber-500 font-bold uppercase tracking-widest">Season 2</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {MOCK_USERS.map(user => (
                    <div key={user.id} className="flex items-center justify-between text-sm px-4 py-2 rounded-xl bg-white/5 border border-white/5">
                      <div className="flex items-center gap-3">
                        <img src={user.avatarUrl} className="w-6 h-6 rounded-full" alt="" />
                        <span className="text-gray-400 font-medium">{user.displayName}:</span>
                      </div>
                      <span className="font-bold text-gray-200">Severance S2</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AwardsPage;
