
import { RankingEntry, User, ActivityEvent, AwardCategory, AwardPick } from './types';
import { USER_IDS } from './constants';

export const MOCK_USERS: User[] = [
  { id: USER_IDS.MATT, displayName: 'Matt', avatarUrl: 'https://picsum.photos/seed/matt/200', role: 'admin' },
  { id: USER_IDS.MIKE, displayName: 'Mike', avatarUrl: 'https://picsum.photos/seed/mike/200', role: 'contributor' },
  { id: USER_IDS.JAKE, displayName: 'Jake', avatarUrl: 'https://picsum.photos/seed/jake/200', role: 'contributor' },
];

const createEntry = (userId: string, rank: number, title: string, season: number, network: string, genres: string[], score: number, rewatch: any): RankingEntry => ({
  id: Math.random().toString(36).substr(2, 9),
  userId,
  rankPosition: rank,
  score,
  rewatchability: rewatch,
  lastRevised: '2025-10-15',
  show: {
    id: title + season,
    tmdbId: Math.floor(Math.random() * 10000),
    title,
    seasonNumber: season,
    posterUrl: `https://picsum.photos/seed/${title}${season}/342/500`,
    network,
    genres,
    airDateStart: '2025-01-01',
    episodeCount: 10,
  }
});

export const MOCK_RANKINGS: Record<string, RankingEntry[]> = {
  [USER_IDS.MATT]: [
    createEntry(USER_IDS.MATT, 1, 'Severance', 2, 'Apple TV+', ['Drama', 'Sci-Fi'], 9.5, 'Instant Classic'),
    createEntry(USER_IDS.MATT, 2, 'The Bear', 4, 'Hulu', ['Drama', 'Comedy'], 9.2, 'High'),
    createEntry(USER_IDS.MATT, 3, 'Andor', 2, 'Disney+', ['Sci-Fi', 'Thriller'], 9.0, 'High'),
    createEntry(USER_IDS.MATT, 4, 'White Lotus', 3, 'HBO', ['Drama', 'Satire'], 8.8, 'Medium'),
    createEntry(USER_IDS.MATT, 5, 'Succession', 4, 'HBO', ['Drama'], 9.8, 'Instant Classic'),
  ],
  [USER_IDS.MIKE]: [
    createEntry(USER_IDS.MIKE, 1, 'Succession', 4, 'HBO', ['Drama'], 9.9, 'Instant Classic'),
    createEntry(USER_IDS.MIKE, 2, 'Severance', 2, 'Apple TV+', ['Drama', 'Sci-Fi'], 9.3, 'High'),
    createEntry(USER_IDS.MIKE, 3, 'The Bear', 4, 'Hulu', ['Drama', 'Comedy'], 9.0, 'High'),
    createEntry(USER_IDS.MIKE, 4, 'Barry', 4, 'HBO', ['Comedy', 'Crime'], 8.9, 'Medium'),
    createEntry(USER_IDS.MIKE, 5, 'White Lotus', 3, 'HBO', ['Drama', 'Satire'], 8.5, 'Low'),
  ],
  [USER_IDS.JAKE]: [
    createEntry(USER_IDS.JAKE, 1, 'Severance', 2, 'Apple TV+', ['Drama', 'Sci-Fi'], 9.4, 'High'),
    createEntry(USER_IDS.JAKE, 2, 'Andor', 2, 'Disney+', ['Sci-Fi', 'Thriller'], 9.3, 'High'),
    createEntry(USER_IDS.JAKE, 3, 'The Bear', 4, 'Hulu', ['Drama', 'Comedy'], 9.1, 'Medium'),
    createEntry(USER_IDS.JAKE, 4, 'Succession', 4, 'HBO', ['Drama'], 8.9, 'High'),
    createEntry(USER_IDS.JAKE, 5, 'Shrinking', 2, 'Apple TV+', ['Comedy'], 8.7, 'Medium'),
  ],
};

export const MOCK_ACTIVITY: ActivityEvent[] = [
  { id: '1', userId: USER_IDS.MATT, type: 'add', timestamp: '2025-10-15T14:30:00Z', metadata: { showName: 'Severance S2', newRank: 1 } },
  { id: '2', userId: USER_IDS.JAKE, type: 'move', timestamp: '2025-10-15T12:00:00Z', metadata: { showName: 'White Lotus S3', oldRank: 5, newRank: 3 } },
  { id: '3', userId: USER_IDS.MIKE, type: 'finalize', timestamp: '2025-10-14T18:00:00Z', metadata: {} },
  { id: '4', userId: USER_IDS.MATT, type: 'blog_post', timestamp: '2025-10-13T10:00:00Z', metadata: { postTitle: 'Why 2025 is the Year of Sci-Fi' } },
];

export const MOCK_AWARD_CATEGORIES: AwardCategory[] = [
  { id: 'c1', name: 'Show of the Year', year: 2025, isPreset: true, unanimous: true },
  { id: 'c2', name: 'Best New Show', year: 2025, isPreset: true },
  { id: 'c3', name: 'Most Disappointing', year: 2025, isPreset: true },
];

export const MOCK_AWARD_PICKS: AwardPick[] = [
  { id: 'p1', categoryId: 'c1', userId: USER_IDS.MATT, showId: 'Severance2' },
  { id: 'p2', categoryId: 'c1', userId: USER_IDS.MIKE, showId: 'Severance2' },
  { id: 'p3', categoryId: 'c1', userId: USER_IDS.JAKE, showId: 'Severance2' },
];
